#include "circle.hpp"
#include "rectangle.hpp"
#include <vector>
#include <iostream>

int main()
{
   std::vector<Form*> forms;
   Rectangle *R = new Rectangle(Point2D(-1,-1),Point2D(1,1));
   Circle *C = new Circle(Point2D(0,0),1);
   
   forms.push_back(R);
   forms.push_back(C);
   
   for(unsigned int i=0;i<forms.size();i++){
       forms[i]->display();
       std::cout << "Area = " << forms[i]->area() << std::endl;
   }
}