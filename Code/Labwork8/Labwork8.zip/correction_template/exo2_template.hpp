//
//  exo2_template.hpp
//  
//
//  Created by emmanuelle on 28/11/2018.
//

#ifndef exo2_template_hpp
#define exo2_template_hpp

#include <stdio.h>

#endif /* exo2_template_hpp */
