#pragma once

#include "Point.hpp"
#include "List.hpp"

class PointList : protected List { // <- PROTECTED, so you list must allow protected access ...
  void cleanup();
  void copy(const PointList&);

public:
  class PointListIterator : public ListIterator {
  public:
    PointListIterator(const PointListIterator&i) : ListIterator(i) {}
    PointListIterator(const PointList&l) : ListIterator(l) {}
    ~PointListIterator() {}

    const Point& head() const // returns the current head of list
    { 
      // TODO
    }
  };

  PointList() : List() {}

  PointList(const PointList&l);

  ~PointList();

  PointList&operator=(const PointList&l);

  // overloading ...
  void add( const Point& p ) {
    // TODO
  }
  
  PointListIterator getIterator() const {
    return PointListIterator(*this);
  }
    
};
