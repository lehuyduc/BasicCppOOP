/*
 *  Circle.hpp
 *  Labwork 5
 *
 *  Created by Lilian Aveneau on 04/11/11.
 *  Copyright 2011 XLIM/SIC/IG. All rights reserved.
 *
 */

#pragma once

#include <cmath>
#include "Graphic.hpp"

class Circle : public virtual Graphic 
{
  // TODO
};
