/*
 *  Diamond.hpp
 *  Labwork5
 *
 *  Created by Lilian Aveneau on 05/11/11.
 *  Copyright 2011 XLIM/SIC/IG. All rights reserved.
 *
 */

#pragma once

#include "Graphic.hpp"

class Diamond : public virtual Graphic 
{
  // TODO
};
