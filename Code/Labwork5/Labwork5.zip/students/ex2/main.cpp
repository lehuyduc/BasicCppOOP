#include <iostream>
#include "List.hpp"

void printDerivativeListDouble( const List& l ) {
  List::ListIterator i2 = l.getIterator();
  i2.next();
  for( List::ListIterator i1 = l.getIterator(); !i2.ended(); i1.next(), i2.next() ){
    const double a = *(const double*)i2.head();
    const double b = *(const double*)i1.head();
    std::cout << (a-b) << " ";
  }
  std::cout<<std::endl;
}


void printListDouble( const List& l ) {
  List::ListIterator iter = l.getIterator();
  for(int i=0; !iter.ended(); ++i) {
    const double*const pd = (const double*)iter.head();
    std::cout << *pd << " ";
    if( (i&0xF) == 0xF ) 
      std::cout << std::endl;
    iter.next();
  }
}

List createListDouble( const double*const d, const unsigned size ) {
  List list;
  for(unsigned i=0; i<size; ++i) {
    list.add(&d[i]);
  }
  return list;
}

int main() {
  const double array[] = {
    0, 1, 2, 3, 4, 5, 6, 7, 8,
    9, 10, 11, 12, 13, 14, 15
  };

  const List list = createListDouble( array, sizeof(array)/sizeof(double) );
  printListDouble( list );

  const List l2 = list;
  printListDouble( List(l2) );

  printDerivativeListDouble( list );

  return 0;
}
