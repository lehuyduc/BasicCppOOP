#pragma once

#include <cstdlib>

class List {
  struct Element {
    const void*m_data;
    // TODO
  };
  Element* m_first;

  // private methods
  void cleanup();
  void copy(const List&);

public:
  class ListIterator {
    // TODO
  public:
    // TODO: constructors, destructor

    const void*head() const // returns the current head of list
    { 
      // TODO
    }
    void next()             // jump to the next element
    {
      // TODO
    }
    bool ended() const      // true if current scan is ended
    {
      // TODO
    }
  };

  // TODO: constructorS, destructor
  
  void add( const void*ptr ) {
    // TODO
  }
 
  ListIterator getIterator() const {
    // TODO
  }
};

    
