#include "List.hpp"

List::List(const List&l) {
  copy(l);
}

void List::copy(const List&l) {
  m_first = NULL;
  for(ListIterator i = l.getIterator(); !i.ended(); i.next()) {
    add(i.head());
  }  
}
  
List::~List() {
  cleanup();
}

void List::cleanup() {
  while(m_first) {
    Element*e = m_first;
    m_first = m_first->m_next;
    delete e;
  }
}

List& List::operator=(const List&l) {
  if( this != &l ) {
    cleanup();
    copy(l);
  }  
  return *this;  
}
