#include <iostream>
#include "Image.h"

/* 
 * Simple function, that displays the program usage, then that exists.
 */
void usage(const char*const name) {
  std::cerr<<"Usage: "<<name<<" input.ppm threshold output.ppm"<<std::endl;
  exit(-1);
}

/* 
 * Main function.
 */
int main( int ac, char**av ) {
  if( ac != 4 ) 
    usage(av[0]);

  const Image in = Image::read( av[1] );
  
  const Image out = in.convert( atof( av[2] ) );

  out.writeP1( av[3] );

  return 0;
}


  
