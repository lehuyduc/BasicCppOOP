#include <cmath>
#include <sstream>
#include "Complex.hpp"

// defines and hides the inner representation of Complex number
#include "Complex_Internal.hpp"

// From now, we do not assume that we use Cartesian or Polar representation ...

void Complex::CartesianToPolar( const double real, const double imag,
				double& mag, double &angle ) {
  mag = sqrt( real*real + imag*imag );
  if( mag == 0.0 ) 
    angle = 0.0;
  else if (real == 0.) {
    // + or - PI/2
    angle = imag < 0. ? -M_PI/2 : imag>0. ? M_PI/2 : 0.;
  }
  else {
    const double at = atan (imag / real);
    angle = real > 0. ? at : (imag < 0. ? at-M_PI : at+M_PI) ;
  }
}


void Complex::PolarToCartesian( const double mag, const double angle, 
				double& real, double& imag ) {
  real = mag*cos(angle);
  imag = mag*sin(angle);
}


double Complex::getReal() const {
  double real, _;
  toCartesian(real, _);
  return real;
}


double Complex::getImaginary() const {
  // TODO
}

double Complex::getMagnitude() const {
  // TODO
}

double Complex::getAngle() const {
  // TODO
}

void Complex::setReal(const double real) {
  double _, imag;
  toCartesian(_, imag);
  *this = fromCartesian(real, imag);
}

void Complex::setImaginary(const double imag) {
  // TODO
}

void Complex::setMagnitude(const double mag) {
  // TODO
}

void Complex::setAngle(const double angle) {
  // TODO
}
  
Complex Complex::add(const Complex& c) const {
  // TODO
}

Complex Complex::sub(const Complex& c) const {
}

Complex Complex::mult(const Complex& c) const {
}

Complex Complex::div(const Complex& c) const {
}

bool Complex::equals(const Complex&c) const {
  // check this using Cartesian representation (where unicity exists)
  // indeed 0exp(itheta) == 0exp(ibeta) ... even if theta != beta
  double tr, ti, cr, ci;
  toCartesian(tr, ti);
  c.toCartesian(cr, ci);
  return tr == cr && ti == ci;
}

bool Complex::equals(const Complex&c, const double& epsilon) const {
  // TODO
}

std::string Complex::printCartesian() const {
  double real, imag;
  toCartesian(real, imag);
  std::ostringstream string; // or with C++11, use std::to_string(real) ...
  string << real;
  string << ( imag<0.0 ? "-i" : "+i");
  string << fabs(imag);
  return string.str();
}


std::string Complex::printPolar() const {
  double mag, angle;
  toPolar(mag, angle);
  std::ostringstream string; // or with C++11, use std::to_string(real) ...
  string << mag << "exp(" << (angle<0.0?"-i":"i") << fabs(angle)<<")";
  return string.str();
}
