#pragma once

// This file concerns the internal representation of complex number.
// If we change it, only this file should be impacted ...

// internal representation is Cartesian ...
#define M_REAL m_inter[0]
#define M_IMAG m_inter[1]

Complex::Complex(const double real, const double imag) {
  M_REAL = real;
  M_IMAG = imag;
}

Complex Complex::fromCartesian( const double real, const double imag ) {
  return Complex(real, imag) ;
}

Complex Complex::fromPolar( const double mag, const double angle ) {
  // we reuse the code already written (to minimize the risk of bugs)
  double real, imag;
  PolarToCartesian( mag, angle, real, imag );
  return Complex( real, imag );
}

void Complex::toCartesian( double&real, double& imag ) const {
  real = M_REAL;
  imag = M_IMAG;
}

void Complex::toPolar( double&mag, double& angle ) const {
  CartesianToPolar(M_REAL, M_IMAG, mag, angle);
}




